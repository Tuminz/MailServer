from LibraryAndUtils import *
from ManageInfo import ManangeUserInfo

class MessageInfo:
    @staticmethod
    def get_to_addresses(mails_address_to, to_email):
        if to_email is not None:
            to_email = to_email.split(',')
            To = [email.strip() for email in to_email]
            mails_address_to.extend(To)
    
    @staticmethod
    def get_cc_addresses(mails_address_cc, cc_email):
        if cc_email is not None:
            cc_email = cc_email.split(',')
            Cc = [email.strip() for email in cc_email]
            mails_address_cc.extend(Cc)
    
    @staticmethod
    def get_bcc_addresses(mails_address_bcc, bcc_email):
        if bcc_email is not None:
            bcc_email = bcc_email.split(',')
            Bcc = [email.strip() for email in bcc_email]
            mails_address_bcc.extend(Bcc)
    
    @staticmethod
    def get_attached_file(input_filename):
        if input_filename == ['']:
            return []
        else:
            return input_filename
    
    @staticmethod
    def generate_message_id():
        return str(uuid.uuid4())
    
    @staticmethod
    def get_domain(From):
        return '@' + From.split('@')[1]

    @staticmethod
    def encode_user_name():
        config = ManangeUserInfo.load_config()
        encoded_name = base64.b64encode(config['NAME'].encode()).decode()
        return f'=?UTF-8?B?{encoded_name}?='

class EmailEncoder:
    @staticmethod
    def encode_and_header_attach_file(file_path, content_type):
        if os.path.exists(file_path):
            with open(file_path, 'rb') as at:
                file_content = at.read()

                file_content_encode = base64.b64encode(file_content).decode(FORMAT)

                file_content_with_newlines = '\r\n'.join(file_content_encode[i:i+100] for i in range(0, len(file_content_encode), 100))

                attachment_header = f"\r\nContent-Type: {content_type}\"{os.path.basename(file_path)}\"" \
                                f"\r\nContent-Disposition: attachment; filename=\"{os.path.basename(file_path)}\"" \
                                "\r\nContent-Transfer-Encoding: base64\r\n\r\n"
                return attachment_header + file_content_with_newlines + "\r\n\r\n"

    @staticmethod       
    def attach_txt_file(file_path):
        if os.path.exists(file_path):
            return EmailEncoder.encode_and_header_attach_file(file_path, CONTENT_TXT)
        else:
            return ""
    
    @staticmethod
    def attach_docx_file(file_path):
        if os.path.exists(file_path):
            return EmailEncoder.encode_and_header_attach_file(file_path, CONTENT_DOCX)
        else:
            return ""

    @staticmethod
    def attach_pdf_file(file_path):
        if os.path.exists(file_path):
            return EmailEncoder.encode_and_header_attach_file(file_path, CONTENT_PDF)
        else:
            return ""
    
    @staticmethod
    def attach_image_file(file_path):
        if os.path.exists(file_path):
            return EmailEncoder.encode_and_header_attach_file(file_path, CONTENT_JPG)
        else:
            return ""

    @staticmethod
    def attach_zip_file( file_path):
        if os.path.exists(file_path):
            return EmailEncoder.encode_and_header_attach_file(file_path, CONTENT_ZIP)
        else:
            return ""
        
class EmailSender:
    @staticmethod
    def send_header(server_socket, From, Type_to, Type_cc, Type_bcc):
        config = ManangeUserInfo.load_config()
        server_socket.send(f"EHLO [{config['SERVER']}]\r\n".encode())
        response = server_socket.recv(HEADER).decode()
        if not response.startswith('250'):
            raise Exception(f"Error sending EHLO: {response}")

        server_socket.send(f"MAIL FROM:<{From}>\r\n".encode())
        response = server_socket.recv(HEADER).decode()
        if not response.startswith('250'):
            raise Exception(f"Error sending mail address: {response}")

        if any(email.strip() for email in Type_to):
            for to_address in Type_to: 
                server_socket.send(f"RCPT TO:<{to_address}>\r\n".encode())
                response = server_socket.recv(HEADER).decode()
                if not response.startswith('250'):
                    raise Exception(f"Error sending mail address: {response}")
                
        if any(email.strip() for email in Type_cc):
            for cc_address in Type_cc: 
                server_socket.send(f"RCPT TO:<{cc_address}>\r\n".encode())
                response = server_socket.recv(HEADER).decode()
                if not response.startswith('250'):
                    raise Exception(f"Error sending mail address: {response}")
        
        if any(email.strip() for email in Type_bcc):
            for bcc_address in Type_bcc: 
                server_socket.send(f"RCPT TO:<{bcc_address}>\r\n".encode())
                response = server_socket.recv(HEADER).decode()
                if not response.startswith('250'):
                    raise Exception(f"Error sending mail address: {response}")

        server_socket.send("DATA\r\n".encode())
        response = server_socket.recv(HEADER).decode()
        if not response.startswith('354'):
            raise Exception(f"Error sending data: {response}")
    
    @staticmethod
    def send_header_normal_mail(server_socket, From):
        message_id = '<' + MessageInfo.generate_message_id() + MessageInfo.get_domain(From) + '>'
        server_socket.send(f"Message-ID: {message_id}\r\n".encode())

        current_time = datetime.now()
        time_format = current_time.strftime("Date: %a,%e %b %Y %H:%M:%S +0700")
        server_socket.send(f"{time_format}\r\n".encode())

        server_socket.send(f"MIME-Version: {MIME_VERSION}\r\n".encode())
        server_socket.send(f"User-Agent: {USER_AGENT}\r\n".encode())
        server_socket.send(f"Content-Language: {CONTENT_LANGUAGE}\r\n".encode())

    @staticmethod
    def send_header_attached_file_mail(server_socket, From):
        server_socket.send(f"Content-Type: multipart/mixed; boundary=\"{BOUNDARY}\"\r\n".encode())
        EmailSender.send_header_normal_mail(server_socket, From)

    @staticmethod
    def send_normal_mail(server_socket, email_data, content):
        email_data += f"Content-Type: {CONTENT_TYPE}\r\nContent-Transfer-Encoding: {CONTENT_TRANSFER_ENCODING}\r\n\r\n{content}\r\n\r\n"
        server_socket.sendall(f"{email_data}.\r\n".encode())

        response = server_socket.recv(HEADER).decode()
        if not response.startswith('250'):
                raise Exception(f"Error sending email: {response}")
        print("Email sent successfully.")

    @staticmethod
    def send_content_of_attached_mail(email_data, server_socket, content):
        email_data += f"\r\n{NOTICE}\r\n--{BOUNDARY}\r\nContent-Type: {CONTENT_TYPE}\r\nContent-Transfer-Encoding: {CONTENT_TRANSFER_ENCODING}\r\n\r\n{content}\r\n\r\n"
        server_socket.sendall(f"{email_data}".encode())
        server_socket.send(f"--{BOUNDARY}".encode())

    @staticmethod
    def send_txt_file(server_socket, email_data, file, content):
        EmailSender.send_content_of_attached_mail(email_data, server_socket, content)
        server_socket.send(f"{EmailEncoder.attach_txt_file(file)}".encode())    
    
    @staticmethod
    def send_docx_file(server_socket, email_data, file, content):
        EmailSender.send_content_of_attached_mail(email_data, server_socket, content)
        server_socket.send(f"{EmailEncoder.attach_docx_file(file)}".encode())    

    @staticmethod
    def send_pdf_file(server_socket, email_data, file, content):
        EmailSender.send_content_of_attached_mail(email_data, server_socket, content)
        server_socket.send(f"{EmailEncoder.attach_pdf_file(file)}".encode())    

    @staticmethod
    def send_image_file(server_socket, email_data, file, content):
        EmailSender.send_content_of_attached_mail(email_data, server_socket, content)
        server_socket.send(f"{EmailEncoder.attach_image_file(file)}".encode())    

    @staticmethod
    def send_zip_file(server_socket, email_data, file, content):
        EmailSender.send_content_of_attached_mail(email_data, server_socket, content)
        server_socket.send(f"{EmailEncoder.attach_zip_file(file)}".encode())    

    @staticmethod
    def send_all_types_of_file(server_socket, From, attach_files, email_data, content):
        EmailSender.send_header_attached_file_mail(server_socket, From)
        for index, file in enumerate(attach_files):
            if file.strip().endswith('.txt'):
                EmailSender.send_txt_file(server_socket, email_data, file, content)
            if file.strip().endswith('.docx'):
                EmailSender.send_docx_file(server_socket, email_data, file, content)
            elif file.strip().endswith('.pdf'):
                EmailSender.send_pdf_file(server_socket, email_data, file, content)
            elif file.strip().endswith('.jpg'):
                EmailSender.send_image_file(server_socket, email_data, file, content)
            elif file.strip().endswith('.zip'):
                EmailSender.send_zip_file(server_socket, email_data, file, content)
            
            if index == len(attach_files) - 1:
                continue
            else:
                server_socket.send(f"--{BOUNDARY}".encode())

        server_socket.send(f"--{BOUNDARY}--\r\n.\r\n".encode())   
        response = server_socket.recv(HEADER).decode()
        if not response.startswith('250'):
                raise Exception(f"Error sending email: {response}")
        print("Email sent successfully.")
    
class ClientSendEmail: 
    def send_bcc_email(From, Bcc, subject, content, attach_files):
        config = ManangeUserInfo.load_config()
        check_attach_file = bool(attach_files)
        user_name_encode = MessageInfo.encode_user_name()

        email_data = f"From: {user_name_encode} <{From}>\r\nSubject: {subject}\r\nTo: {BCC_NOTICE}\r\n"

        with socket.create_connection((config['SERVER'], config['SMTP_PORT'])) as server_socket:
            response = server_socket.recv(HEADER).decode()
            if not response.startswith('220'):
                raise Exception(f"Error connecting to server: {response}")
            
            EmailSender.send_header(server_socket, From, [], [], Bcc)

            if check_attach_file == True:
                EmailSender.send_all_types_of_file(server_socket, From, attach_files, email_data, content)
            else:
                EmailSender.send_header_normal_mail(server_socket, From)
                EmailSender.send_normal_mail(server_socket, email_data, content)
            
            server_socket.send("QUIT\r\n".encode())

    def send_email(from_address, to_addresses, cc_addresses, bcc_addresses, subject, content, attach_files):
        config = ManangeUserInfo.load_config()
        check_attach_file = bool(attach_files)
        email_data = ""

        if any(email.strip() for email in to_addresses):
            to_address = ', '.join(to_addresses)
            email_data += f"To: {to_address}\r\n"
        if any(email.strip() for email in cc_addresses):
            cc_address = ', '.join(cc_addresses)
            email_data += f"Cc: {cc_address}\r\n"
        
        if not any(email.strip() for email in to_addresses) and not any(email.strip() for email in cc_addresses):
            ClientSendEmail.send_bcc_email(from_address, bcc_addresses, subject, content, attach_files)
            return

        user_name_encode = MessageInfo.encode_user_name()
        
        email_data += f"From: {user_name_encode} <{from_address}>\r\nSubject: {subject}\r\n"
        with socket.create_connection((config['SERVER'], config['SMTP_PORT'])) as server_socket:
            response = server_socket.recv(HEADER).decode()
            if not response.startswith('220'):
                raise Exception(f"Error connecting to server: {response}")

            EmailSender.send_header(server_socket, from_address, to_addresses, cc_addresses, bcc_addresses)
            
            if check_attach_file == True:
                EmailSender.send_all_types_of_file(server_socket, from_address, attach_files, email_data, content)
            else:
                EmailSender.send_header_normal_mail(server_socket, from_address)
                EmailSender.send_normal_mail(server_socket, email_data, content)

            server_socket.send("QUIT\r\n".encode()) 

    @staticmethod
    def start_sending_process(input_to, input_cc, input_bcc, input_subject, input_content, input_filename):
        mails_address_to = []
        mails_address_cc = []
        mails_address_bcc = [] 

        From = ManangeUserInfo.load_config()['EMAIL']

        MessageInfo.get_to_addresses(mails_address_to, input_to)
        MessageInfo.get_cc_addresses(mails_address_cc, input_cc)
        MessageInfo.get_bcc_addresses(mails_address_bcc, input_bcc)
    
        subject = input_subject
        content = input_content

        attach_files_path = MessageInfo.get_attached_file(input_filename)

        ClientSendEmail.send_email(From, mails_address_to, mails_address_cc, mails_address_bcc, subject, content, attach_files_path)